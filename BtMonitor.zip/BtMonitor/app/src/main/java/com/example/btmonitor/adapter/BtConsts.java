package com.example.btmonitor.adapter;

public class BtConsts {
    public static final String MY_PREF = "my_pref";
    public static final String MAC_KEY = "mac_key";
}
